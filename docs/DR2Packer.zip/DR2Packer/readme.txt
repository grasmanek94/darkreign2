===========================
     drpackez v0.05beta
        Marcus Luk
         00/08/08 
===========================

www.mindspring.com/~gunnar01/drpackez/

drpackez@springmail.com

DESCRIPTION
~~~~~~~~~~~
DrPackez simplifies the process of packing and unpacking .ZWP files used in Dark Reign 2 (DR2).
DrPackez is a front-end for use with drpack.exe (on the DR2 CDRom).
Pack and unpack files by right clicking on them in Windows Explorer.

WHAT'S NEW
~~~~~~~~~~
Now recurses subdirectories when packing a folder.


INSTALLATION
~~~~~~~~~~~~
Unzip files to a folder of your choice. 
Copy drpack.exe to the same folder where you unzipped the files.
(drpack.exe should be in the \Editor\ directory of the DR2 CDRom.)
Run Install_dp.exe  

UNINSTALLATION
~~~~~~~~~~~~~~
Run Install_dp.exe 
       or 
Select Uninstall DrPackez from the [Add/Remove Programs] Control Panel Applet.
(Program will delete the appropriate registry keys.)
Delete folder & files manually.

USAGE
~~~~~
Right click on any .ZWP file or on any directory while browsing in an Explorer window.
Select the appropriate command:
  Unpack with DrPack
         or 
  Pack Folder with DrPack

WARNINGS
~~~~~~~~
Program does NOT prompt on overwrites.
USE AT YOUR OWN RISK.
Backup your .ZWP files before using.

ISSUES
~~~~~~
Program does not tell you if a .ZWP file is empty. 
It just looks like nothing happens.

ETC
~~~
Tested using win98.
Powered by Delphi.
Dark Reign 2 and drpack are from Pandemic Studios, Inc